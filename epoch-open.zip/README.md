# epoch-open

Free replacement software for a BioTek Epoch microplate spectrophotometer with a Take3
micro-volume plate, for RNA/DNA quantification.

The lab owns the instrument. The vendor software's licence activations are exhausted, so
the instrument is becoming unusable for want of a program to drive it. This project
writes a new program that talks to the reader directly. It does not modify, patch,
bypass or inspect the vendor software, and nothing here depends on it at runtime.

## Who uses this

The daily user is a lab technician who is not a computer person. That constrains the
design more than anything technical does:

- Ships as a **single `.exe`** on Windows. Double-click. No Python, no install, no
  console window, no config files to edit.
- Main screen is a **Take3 plate layout** she clicks to mark loaded spots, copying the
  Gen5 picker she already knows.
- Three buttons: **Read blank**, **Read samples**, **Save results**.
- Results export to **xlsx**, the same format Gen5 produces, so everything she does with
  the file afterwards is unchanged.
- Sample type (dsDNA / ssDNA / RNA) is a dropdown, defaulted to whatever the lab uses most.
- Problems are reported in plain language next to the affected well, never as an error
  code or a traceback.

## Status

| Piece | State |
|---|---|
| Quantification math (`epoch_open/quant.py`) | Done, reproduces this lab's Gen5 numbers |
| xlsx export (`epoch_open/xlsx.py`) | Done, no dependencies, verified opens in LibreOffice |
| Take3 layout (`epoch_open/take3.py`) | Done, confirmed from the factory sheet (A2-H3) |
| Reader interface + simulator (`epoch_open/reader.py`) | Done |
| Technician GUI (`epoch_open/gui.py`) | Working against the real instrument |
| Test suite | 155 tests passing |
| Protocol capture procedure (`docs/CAPTURE.md`) | No longer needed |
| Serial protocol decode | **Done** — reads confirmed on the instrument |
| USB transport | **Solved** — reader is FTDI virtual COM, pyserial talks to it (`docs/FINDINGS.md`) |
| Instrument driver | Connect, carriage, capabilities, batched multi-wavelength reads |
| Validated against Gen5 | **Yes** — 0.5% on neat ladder, same drops (`docs/VALIDATION.md`) |

Remaining: package the Windows .exe for the lab laptop, and let the technician try the interface. Everything else is done and verified on the instrument.

## The approach

1. **Capture** the serial conversation between Gen5 and the reader during one real Take3
   read, while the Gen5 trial still runs. See `docs/CAPTURE.md`. **Time-critical.**
2. **Decode** the captured bytes into a command set: move carriage, select wavelength,
   read, return values. [PyLabRobot](https://github.com/PyLabRobot/pylabrobot) already has
   a `BioTekPlateReaderBackend` whose version/serial/door commands reportedly work on an
   original Epoch; its read commands do not, apparently because the command set varies by
   firmware. The capture closes exactly that gap, and the result is worth contributing
   back upstream.
3. **Driver** — a small Python module over the reader's USB virtual COM port. The
   original disks confirm the Epoch is an FTDI USB-to-serial device, so this is
   plain pyserial over a COM port; see `docs/FINDINGS.md`.
4. **GUI** — Tkinter, bundled with PyInstaller into one `.exe`.
5. **Validate** — run the same plate through the captured Gen5 reference numbers and this
   software, and confirm they agree well by well before it is used for real samples.

## Quantification

Recovered from this lab's own Gen5 exports and verified against them: subtract the
320 nm reference from each measurement wavelength, subtract the per-well blank, scale
from the 0.5 mm Take3 path to 1 cm, multiply by the extinction factor. For dsDNA that
reduces to `ng/uL = A260 x 1000`.

The derivation, and two assumptions this project got wrong before the real exports
arrived, are in `docs/QUANTIFICATION.md`.

## Running it today

The whole program works now against a built-in simulator, so the screen and the
spreadsheet can be reviewed before the instrument is talking:

    python3 run_gui.py

It opens with a red banner saying the numbers are simulated, and any file it saves
carries the same warning inside. Needs tkinter (bundled with Python on Windows; on
Debian/Ubuntu `apt install python3-tk`).

## Running the tests

    python3 tests/run_tests.py     # no dependencies
    python3 -m pytest tests/ -q    # if pytest is installed

## Layout

    epoch_open/quant.py    quantification, pathlength correction, purity ratios
    tests/                 test suite and a dependency-free runner
    docs/CAPTURE.md        how to capture the protocol from the running Gen5
    docs/FINDINGS.md       what the original instrument disks established
    captures/             (empty) .pcapng files and Gen5 reference numbers go here
